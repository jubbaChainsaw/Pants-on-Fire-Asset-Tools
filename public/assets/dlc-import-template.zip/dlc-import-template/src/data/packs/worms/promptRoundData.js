export const WormsPromptRoundData = {
  id: 'worms',
  name: 'Worms',
  emoji: '🪱',
  prompts: [
    { hint: 'Garden Worm', main: 'Earthworm', imposter: 'Nightcrawler' },
    { hint: 'Compost Crew', main: 'Red Wiggler', imposter: 'Tiger Worm' },
    { hint: 'Marine Worm', main: 'Bristle Worm', imposter: 'Ragworm' },
    { hint: 'Silk Worm', main: 'Silkworm', imposter: 'Mealworm' },
    { hint: 'Dusty Hookup Story (18+)', main: 'Woke up in the wrong tent', imposter: 'Accidentally texted your ex from a festival field', adultOnly: true },
  ],
};
