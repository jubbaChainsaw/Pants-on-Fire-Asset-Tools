Place PNGs referenced by manifest.json in this folder.
Required file naming: exactly match each entry's mainMediaFile and imposterMediaFile.
